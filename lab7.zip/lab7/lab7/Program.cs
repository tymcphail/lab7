﻿using static System.Console;
//S2335,lab 7 due april 9, section 4232, this program displays stars
public class Pattern
{
    public static void Main()
    {
        int userInput = 0;

        bool ToF = false;
        //validations
        do
        {
            Write("Enter Number of Stars:");

            ToF = int.TryParse(ReadLine(), out userInput) && userInput > 0;

            ShowSquareOfStars(userInput);
        }
        while (!ToF);
        {

        }

    }
    public static void ShowSquareOfStars(int var)
    {
        // loop till i is less than or equal 
        for (int i = 1; i <= var; i++)
        {
            //loop till i is less than or equal 
            for (int x = 1; x <= var; x++)

                Write("*"); // printing the stars
            Write("\n"); // printing the next5 line
            
        }
    }
}
